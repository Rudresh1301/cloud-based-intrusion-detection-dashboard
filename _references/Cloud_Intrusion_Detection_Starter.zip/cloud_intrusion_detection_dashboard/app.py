import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path
from detector import analyze_logs

st.set_page_config(
    page_title="Cloud-Based Intrusion Detection Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Keep the approved palette unchanged: dark navy, electric blue, neon cyan,
# purple, red, and green.
st.markdown("""
<style>
:root {
  --bg: #080D19; --panel: #121E32; --sidebar: #0D1526;
  --blue: #00A8FF; --cyan: #00C8FF; --purple: #8B5CF6;
  --red: #FF4560; --green: #00D68F; --text: #F1F5F9;
}
.stApp { background: var(--bg); color: var(--text); }
[data-testid="stSidebar"] { background: var(--sidebar); border-right: 1px solid #12345A; }
.block-container { padding-top: 1.5rem; }
.metric-card {
  background: linear-gradient(135deg, #122541, #101A2D);
  border: 1px solid #164879; border-radius: 14px;
  padding: 17px 18px; min-height: 112px;
}
.metric-label { color: #9CC9E8; font-size: 0.92rem; }
.metric-value { color: #F1F5F9; font-size: 1.9rem; font-weight: 750; margin-top: 5px; }
.panel {
  background: #0D192B; border: 1px solid #153B61;
  border-radius: 14px; padding: 16px;
}
h1, h2, h3 { color: #F1F5F9; }
div[data-testid="stDataFrame"] { border: 1px solid #153B61; border-radius: 10px; }
.stButton button, .stDownloadButton button {
  background: linear-gradient(90deg, #087FE5, #00A8FF);
  color: white; border: 0; border-radius: 9px; font-weight: 650;
}
.small-muted { color: #9CB4CC; font-size: 0.85rem; }
</style>
""", unsafe_allow_html=True)

SAMPLE = Path(__file__).parent / "data" / "sample_logs.csv"

def load_sample():
    return pd.read_csv(SAMPLE)

st.sidebar.markdown("## 🛡️ Cloud IDS")
st.sidebar.caption("MONITOR • DETECT • PROTECT")
page = st.sidebar.radio("NAVIGATION", ["Dashboard", "Upload Logs", "Threat Analysis", "About"])
st.sidebar.markdown("---")
st.sidebar.markdown("🟢 **Detection engine ready**")
st.sidebar.caption("Prototype mode • Log-file analysis")

st.title("Cloud-Based Intrusion Detection Dashboard")
st.markdown("<p class='small-muted'>Analyze application access logs and identify potentially suspicious activity.</p>", unsafe_allow_html=True)

if "logs" not in st.session_state:
    st.session_state.logs = load_sample()

if page == "About":
    st.subheader("Project overview")
    st.write(
        "This prototype analyzes uploaded application or network-style logs. "
        "It uses transparent rule-based checks to flag repeated failed logins, "
        "suspicious event types, and unusual request patterns."
    )
    st.info("This version analyzes uploaded/sample logs. It does not monitor a real network or block traffic.")
    st.markdown("**Expected CSV columns:** timestamp, source_ip, username, event_type, status, endpoint.")
    st.stop()

if page == "Upload Logs":
    st.subheader("Upload application or network logs")
    st.write("Upload a CSV file with the required columns. A sample dataset is available below.")
    uploaded = st.file_uploader("Choose a CSV file", type=["csv"])
    if uploaded is not None:
        try:
            new_logs = pd.read_csv(uploaded)
            required = {"timestamp", "source_ip", "username", "event_type", "status", "endpoint"}
            missing = required - set(new_logs.columns)
            if missing:
                st.error("Missing required columns: " + ", ".join(sorted(missing)))
            else:
                st.session_state.logs = new_logs
                st.success(f"Loaded {len(new_logs):,} log records successfully.")
        except Exception as exc:
            st.error(f"Could not read this CSV: {exc}")
    st.download_button(
        "Download sample log CSV",
        data=SAMPLE.read_bytes(),
        file_name="sample_logs.csv",
        mime="text/csv",
    )

logs = st.session_state.logs.copy()
alerts, enriched = analyze_logs(logs)

if page == "Threat Analysis":
    st.subheader("Threat analysis")
    if alerts.empty:
        st.success("No suspicious activity detected in the current log set.")
    else:
        severity_filter = st.multiselect(
            "Filter by severity", ["Critical", "High", "Medium", "Low"],
            default=["Critical", "High", "Medium", "Low"]
        )
        shown = alerts[alerts["severity"].isin(severity_filter)]
        st.dataframe(shown, use_container_width=True, hide_index=True)
        st.download_button(
            "Download detected alerts",
            data=shown.to_csv(index=False).encode("utf-8"),
            file_name="security_alerts.csv",
            mime="text/csv",
        )
    st.stop()

# Dashboard
total = len(enriched)
threat_count = len(alerts)
suspicious_ips = alerts["source_ip"].nunique() if not alerts.empty else 0
critical_count = int((alerts["severity"] == "Critical").sum()) if not alerts.empty else 0

cols = st.columns(4)
metrics = [
    ("TOTAL LOG EVENTS", f"{total:,}", "📡"),
    ("THREATS FLAGGED", f"{threat_count:,}", "🚨"),
    ("SUSPICIOUS IPs", f"{suspicious_ips:,}", "🌐"),
    ("CRITICAL ALERTS", f"{critical_count:,}", "🛡️"),
]
for col, (label, value, icon) in zip(cols, metrics):
    with col:
        st.markdown(
            f"<div class='metric-card'><div class='metric-label'>{icon} {label}</div>"
            f"<div class='metric-value'>{value}</div></div>",
            unsafe_allow_html=True
        )

st.write("")
left, middle, right = st.columns([1.35, 1, 1.2])

with left:
    st.markdown("### 📈 Event activity")
    activity = enriched.copy()
    activity["timestamp"] = pd.to_datetime(activity["timestamp"], errors="coerce")
    activity = activity.dropna(subset=["timestamp"])
    if not activity.empty:
        activity = activity.set_index("timestamp").resample("h").size().reset_index(name="events")
        fig = px.line(activity, x="timestamp", y="events", markers=True)
        fig.update_traces(line=dict(color="#00A8FF", width=3), marker=dict(size=6))
        fig.update_layout(
            height=300, margin=dict(l=5,r=5,t=15,b=5),
            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            font_color="#DCEBFA", xaxis_title="", yaxis_title="Events",
        )
        fig.update_xaxes(gridcolor="#1B3451")
        fig.update_yaxes(gridcolor="#1B3451")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No valid timestamps available to chart.")

with middle:
    st.markdown("### 🎯 Severity distribution")
    if not alerts.empty:
        sev = alerts["severity"].value_counts().rename_axis("severity").reset_index(name="count")
        fig = px.pie(sev, names="severity", values="count", hole=0.62,
                     color="severity",
                     color_discrete_map={"Critical":"#FF4560","High":"#FF9F1A","Medium":"#8B5CF6","Low":"#00C8FF"})
        fig.update_layout(height=300, margin=dict(l=5,r=5,t=15,b=5),
                          paper_bgcolor="rgba(0,0,0,0)", font_color="#DCEBFA",
                          legend_title_text="")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No alerts to classify yet.")

with right:
    st.markdown("### 🚩 Alert categories")
    if not alerts.empty:
        counts = alerts["alert_type"].value_counts().reset_index()
        counts.columns = ["Alert type", "Count"]
        fig = px.bar(counts, x="Count", y="Alert type", orientation="h",
                     color_discrete_sequence=["#00C8FF"])
        fig.update_layout(height=300, margin=dict(l=5,r=5,t=15,b=5),
                          paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                          font_color="#DCEBFA", xaxis_title="", yaxis_title="")
        fig.update_xaxes(gridcolor="#1B3451")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No alert categories yet.")

st.write("")
a, b = st.columns([1, 1.6])
with a:
    st.markdown("### 🏆 Top flagged IP addresses")
    if not alerts.empty:
        top_ips = alerts.groupby("source_ip").size().sort_values(ascending=False).head(5).reset_index(name="alerts")
        st.dataframe(top_ips, use_container_width=True, hide_index=True)
    else:
        st.caption("No suspicious IP addresses found.")

with b:
    st.markdown("### 🔔 Recent security alerts")
    if not alerts.empty:
        st.dataframe(alerts.head(8), use_container_width=True, hide_index=True)
    else:
        st.success("No suspicious activity detected in the current log set.")

st.caption("Prototype notice: findings are generated from the loaded dataset using rule-based checks. They are not proof of a real attack.")
