# Cloud-Based Intrusion Detection Dashboard

A Streamlit prototype that analyzes uploaded CSV application/network-style logs and flags potentially suspicious activity.

## Run locally (Windows)

1. Install Python 3.10 or newer.
2. Open this folder in VS Code.
3. Open Terminal and run:

```powershell
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```

## CSV format

The uploaded CSV must contain these columns:

- `timestamp`
- `source_ip`
- `username`
- `event_type`
- `status`
- `endpoint`

Use **Upload Logs** to upload a CSV or download the included sample.

## Current detection rules

- Five or more failed events from one IP: High alert.
- Ten or more failed events from one IP: Critical alert.
- Event/endpoint contains SQL injection, command injection, path traversal, XSS, or malware: High alert.
- Twenty or more events from one IP in the uploaded dataset: Medium alert.

This is an educational prototype. It analyzes the provided log data; it does not monitor a live network, verify IP reputation, or block traffic.
