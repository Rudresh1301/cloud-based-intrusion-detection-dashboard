import pandas as pd

REQUIRED_COLUMNS = {"timestamp", "source_ip", "username", "event_type", "status", "endpoint"}

def analyze_logs(logs: pd.DataFrame):
    """Return (alerts, enriched_logs) using explainable starter detection rules."""
    df = logs.copy()
    missing = REQUIRED_COLUMNS - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {', '.join(sorted(missing))}")

    df["timestamp"] = pd.to_datetime(df["timestamp"], errors="coerce")
    for col in ["source_ip", "username", "event_type", "status", "endpoint"]:
        df[col] = df[col].fillna("unknown").astype(str)

    df["is_failed"] = df["status"].str.lower().isin(["failed", "failure", "denied", "401", "403"])
    alerts = []

    # Rule 1: repeated failed logins from one IP.
    failed = df[df["is_failed"]]
    for ip, group in failed.groupby("source_ip"):
        if len(group) >= 5:
            alerts.append({
                "timestamp": group["timestamp"].max(),
                "source_ip": ip,
                "username": ", ".join(sorted(group["username"].unique())[:3]),
                "alert_type": "Repeated failed logins",
                "severity": "Critical" if len(group) >= 10 else "High",
                "evidence": f"{len(group)} failed events from this IP",
            })

    # Rule 2: suspicious event keywords.
    keywords = ["sql injection", "command injection", "path traversal", "xss", "malware"]
    for _, row in df.iterrows():
        event_text = (row["event_type"] + " " + row["endpoint"]).lower()
        matched = next((word for word in keywords if word in event_text), None)
        if matched:
            alerts.append({
                "timestamp": row["timestamp"],
                "source_ip": row["source_ip"],
                "username": row["username"],
                "alert_type": f"Suspicious pattern: {matched}",
                "severity": "High",
                "evidence": f"Matched keyword '{matched}' in event or endpoint",
            })

    # Rule 3: unusually high event volume from a single IP.
    counts = df["source_ip"].value_counts()
    for ip, count in counts.items():
        if count >= 20:
            alerts.append({
                "timestamp": df.loc[df["source_ip"] == ip, "timestamp"].max(),
                "source_ip": ip,
                "username": "multiple/unknown",
                "alert_type": "High request volume",
                "severity": "Medium",
                "evidence": f"{count} events from this IP in the uploaded dataset",
            })

    alert_df = pd.DataFrame(alerts, columns=[
        "timestamp", "source_ip", "username", "alert_type", "severity", "evidence"
    ])
    if not alert_df.empty:
        alert_df = alert_df.sort_values("timestamp", ascending=False, na_position="last")
        alert_df["timestamp"] = alert_df["timestamp"].astype(str)

    return alert_df, df
